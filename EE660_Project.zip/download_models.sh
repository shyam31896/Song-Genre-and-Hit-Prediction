wget https://www.dropbox.com/s/c9y9uykc55xvjiz/models.tar.gz?dl=0
mv models.tar.gz\?dl=0 models.tar.gz
tar -xvzf models.tar.gz
rm -rf models.tar.gz
